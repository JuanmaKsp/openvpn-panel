@extends('admin.layout')

@section('title', 'Nuevo cliente VPN')

@section('admin-content')
<div class="card">
    <div class="card-header fw-semibold">Crear cliente</div>
    <div class="card-body">
        <form method="POST" action="{{ route('admin.vpn.store') }}" class="row g-3">
            @csrf

            <div class="col-md-4">
                <label class="form-label">Nombre base (ej: juan)</label>
                <input name="base_name" class="form-control" required value="{{ old('base_name') }}">
                <div class="form-text">Solo letras, números, _ y -</div>
            </div>

            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input name="email" type="email" class="form-control" required value="{{ old('email') }}">
            </div>

            <div class="col-md-4">
              <label class="form-label">Validez (meses)</label>
              <div class="input-group">
                <input id="validity_months" name="validity_months" type="number" min="1" max="120"
                  class="form-control" value="{{ old('validity_months', 24) }}" required>
                <span class="input-group-text">meses</span>
              </div>
              <div class="form-text">
                Chuleta:
                <button type="button" class="btn btn-link btn-sm p-0" onclick="setMonths(6)">6 meses</button> ·
                <button type="button" class="btn btn-link btn-sm p-0" onclick="setMonths(24)">2 años</button> ·
                <button type="button" class="btn btn-link btn-sm p-0" onclick="setMonths(48)">4 años</button>
              </div>
            </div>

            <script>
            function setMonths(m){ document.getElementById('validity_months').value = m; }
            </script>

            <div class="col-md-4">
                <label class="form-label">Private subnet (opcional)</label>
                <input name="private_subnet" class="form-control" placeholder="10.8.1.0/24" value="{{ old('private_subnet') }}">
            </div>

            <div class="col-md-4">
                <label class="form-label">Puerto cliente (opcional)</label>
                <input name="port" type="number" class="form-control" min="1" max="65535" value="{{ old('port') }}">
            </div>

            <div class="col-12 d-flex gap-2">
                <button class="btn btn-primary" type="submit">Crear</button>
                <a class="btn btn-outline-secondary" href="{{ route('admin.vpn.index') }}">Cancelar</a>
            </div>
        </form>
    </div>
</div>
@endsection
