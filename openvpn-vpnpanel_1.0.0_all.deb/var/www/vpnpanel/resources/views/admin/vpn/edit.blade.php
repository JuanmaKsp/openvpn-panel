@extends('admin.layout')

@section('title', 'Editar cliente VPN')

@section('admin-content')
<div class="card">
    <div class="card-header fw-semibold">Editar cliente</div>
    <div class="card-body">
        <form method="POST" action="{{ route('admin.vpn.update', $vpnClient) }}" class="row g-3">
            @csrf
            @method('PUT')

            <div class="col-md-4">
                <label class="form-label">Nombre base</label>
                <input class="form-control" value="{{ $vpnClient->base_name }}" disabled>
            </div>

            <div class="col-md-8">
                <label class="form-label">CN actual</label>
                <input class="form-control" value="{{ $vpnClient->cn }}" disabled>
            </div>

            <div class="col-md-6">
                <label class="form-label">Email</label>
                <input name="email" type="email" class="form-control" required value="{{ old('email', $vpnClient->email) }}">
            </div>

            <div class="col-md-6">
              <label class="form-label">Validez (meses)</label>
              <div class="input-group">
                <input id="validity_months" name="validity_months" type="number" min="1" max="120"
                  class="form-control" value="{{ old('validity_months', $vpnClient->validity_months ?? 24) }}" required>
                <span class="input-group-text">meses</span>
              </div>
              <div class="form-text">
                Cambiar este valor no modifica el certificado actual. Se aplica al <b>Renovar</b> (nuevo .ovpn).
                <br>
                Chuleta:
                <button type="button" class="btn btn-link btn-sm p-0" onclick="setMonths(6)">6 meses</button> �
                <button type="button" class="btn btn-link btn-sm p-0" onclick="setMonths(24)">2 a�os</button> �
                <button type="button" class="btn btn-link btn-sm p-0" onclick="setMonths(48)">4 a�os</button>
              </div>
            </div>

            <script>
            function setMonths(m){ document.getElementById('validity_months').value = m; }
            </script>

            <div class="col-12 d-flex gap-2">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <a class="btn btn-outline-secondary" href="{{ route('admin.vpn.index') }}">Volver</a>
            </div>
        </form>
    </div>
</div>
@endsection
