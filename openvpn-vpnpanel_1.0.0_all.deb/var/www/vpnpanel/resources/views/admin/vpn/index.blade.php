@extends('admin.layout')

@section('title', 'VPN')

@section('admin-content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="fw-semibold">Clientes VPN</span>
        <a class="btn btn-primary btn-sm" href="{{ route('admin.vpn.create') }}">Nuevo cliente</a>
    </div>

    <div class="table-responsive">
        <table class="table table-sm mb-0 align-middle">
            <thead>
                <tr>
                    <th>Base</th>
                    <th>CN actual</th>
                    <th>Email</th>
                    <th>Validez</th>
                    <th>Cert expira</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            @forelse($items as $it)
                <tr>
                    <td class="fw-semibold">{{ $it->base_name }}</td>
                    <td><code>{{ $it->cn }}</code></td>
                    <td>{{ $it->email }}</td>
                    <td>{{ $it->validity_months ?? 24 }} meses</td>
                    <td>{{ optional($it->cert_not_after_at)->format('d/m/Y') ?? '—' }}</td>
                    <td class="text-end">
                        <div class="btn-group btn-group-sm" role="group">
                            <a class="btn btn-outline-secondary" href="{{ route('admin.vpn.edit', $it) }}">Editar</a>
                            <a class="btn btn-outline-secondary" href="{{ route('admin.vpn.download', $it) }}">Descargar</a>

                            <form method="POST" action="{{ route('admin.vpn.renew', $it) }}" onsubmit="return confirm('¿Renovar? (revoca el perfil actual y genera uno nuevo)')">
                                @csrf
                                <button class="btn btn-outline-primary" type="submit">Renovar</button>
                            </form>

                            <form method="POST" action="{{ route('admin.vpn.revoke', $it) }}" onsubmit="return confirm('¿Revocar? (bloquea acceso)')">
                                @csrf
                                <button class="btn btn-outline-danger" type="submit">Revocar</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="text-center text-muted py-4">No hay clientes todavía.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
