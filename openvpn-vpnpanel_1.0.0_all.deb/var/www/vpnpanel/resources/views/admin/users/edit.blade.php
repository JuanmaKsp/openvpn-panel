@extends('admin.layout')

@section('title', 'Editar usuario')

@section('admin-content')
<div class="card">
    <div class="card-header fw-semibold">Editar usuario</div>
    <div class="card-body">
        <form method="POST" action="{{ route('admin.users.update', $user) }}" class="row g-3">
            @csrf
            @method('PUT')

            <div class="col-md-4">
                <label class="form-label">Nombre</label>
                <input name="name" class="form-control" required value="{{ old('name', $user->name) }}">
            </div>

            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input name="email" type="email" class="form-control" required value="{{ old('email', $user->email) }}">
            </div>

            <div class="col-md-4">
                <label class="form-label">Nueva contraseña (opcional)</label>
                <input name="password" type="password" class="form-control">
            </div>

            <div class="col-12">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_admin" value="1" id="is_admin" {{ $user->is_admin ? 'checked' : '' }}>
                    <label class="form-check-label" for="is_admin">Administrador</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active" {{ $user->is_active ? 'checked' : '' }}>
                    <label class="form-check-label" for="is_active">Activo</label>
                </div>
            </div>

            <div class="col-12 d-flex gap-2">
                <button class="btn btn-primary" type="submit">Guardar</button>
                <a class="btn btn-outline-secondary" href="{{ route('admin.users.index') }}">Volver</a>
            </div>
        </form>
    </div>
</div>
@endsection
