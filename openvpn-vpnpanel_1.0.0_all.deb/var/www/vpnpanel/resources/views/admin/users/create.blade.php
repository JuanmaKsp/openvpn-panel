@extends('admin.layout')

@section('title', 'Nuevo usuario')

@section('admin-content')
<div class="card">
    <div class="card-header fw-semibold">Crear usuario</div>
    <div class="card-body">
        <form method="POST" action="{{ route('admin.users.store') }}" class="row g-3">
            @csrf

            <div class="col-md-4">
                <label class="form-label">Nombre</label>
                <input name="name" class="form-control" required value="{{ old('name') }}">
            </div>

            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input name="email" type="email" class="form-control" required value="{{ old('email') }}">
            </div>

            <div class="col-md-4">
                <label class="form-label">Contraseña</label>
                <input name="password" type="password" class="form-control" required>
                <div class="form-text">Mínimo 10 caracteres</div>
            </div>

            <div class="col-12">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_admin" value="1" id="is_admin">
                    <label class="form-check-label" for="is_admin">Administrador</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active" checked>
                    <label class="form-check-label" for="is_active">Activo</label>
                </div>
            </div>

            <div class="col-12 d-flex gap-2">
                <button class="btn btn-primary" type="submit">Crear</button>
                <a class="btn btn-outline-secondary" href="{{ route('admin.users.index') }}">Cancelar</a>
            </div>
        </form>
    </div>
</div>
@endsection
