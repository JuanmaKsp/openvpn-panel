@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
        <h1 class="h5 mb-0">@yield('title', 'Administración')</h1>

        <div class="btn-group">
            <a class="btn btn-outline-secondary btn-sm" href="{{ route('admin.vpn.index') }}">VPN</a>
            <a class="btn btn-outline-secondary btn-sm" href="{{ route('admin.users.index') }}">Usuarios</a>
        </div>
    </div>

    @if(session('ok'))
        <div class="alert alert-success">{{ session('ok') }}</div>
    @endif
    @if($errors->any())
        <div class="alert alert-danger mb-3">
            <div class="fw-semibold mb-1">Hay errores:</div>
            <ul class="mb-0">
                @foreach($errors->all() as $e)
                    <li>{{ $e }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @yield('admin-content')
</div>
@endsection
