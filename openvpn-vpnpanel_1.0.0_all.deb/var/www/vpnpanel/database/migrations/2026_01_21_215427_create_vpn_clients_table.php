<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVpnClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vpn_clients', function (Blueprint $table) {
            $table->id();
            $table->string('base_name', 64);
            $table->string('cn', 96)->unique();          // CN real en OpenVPN
            $table->string('email', 190);
            $table->timestamp('access_expires_at')->nullable(); // caducidad “de negocio”
            $table->string('cert_enddate')->nullable();         // notAfter=...
            $table->boolean('is_current')->default(true);
            $table->string('status', 16)->default('active');    // active|revoked
            $table->timestamp('revoked_at')->nullable();
	    $table->timestamps();

	    $table->index(['base_name','is_current']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vpn_clients');
    }
}
