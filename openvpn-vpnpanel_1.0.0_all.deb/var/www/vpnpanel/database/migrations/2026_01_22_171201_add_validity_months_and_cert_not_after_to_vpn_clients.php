<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddValidityMonthsAndCertNotAfterToVpnClients extends Migration
{
    public function up()
    {
        Schema::table('vpn_clients', function (Blueprint $table) {
            $table->unsignedSmallInteger('validity_months')->default(24)->after('email');
            $table->timestamp('cert_not_after_at')->nullable()->after('cert_enddate');
        });
    }

    public function down()
    {
        Schema::table('vpn_clients', function (Blueprint $table) {
            $table->dropColumn(['validity_months', 'cert_not_after_at']);
        });
    }
}
