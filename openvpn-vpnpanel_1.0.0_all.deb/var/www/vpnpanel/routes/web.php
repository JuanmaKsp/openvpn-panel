<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return auth()->check() ? redirect('/home') : redirect()->route('login');
});

Auth::routes(['register' => false]);
Route::get('/home', function () {
    return (auth()->check() && auth()->user()->is_admin) ? redirect('/admin') : app(App\Http\Controllers\HomeController::class)->index();
})->name('home');


Route::middleware(['auth','admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', fn() => redirect()->route('admin.vpn.index'))->name('home');

    Route::resource('users', \App\Http\Controllers\Admin\UserController::class)
        ->only(['index','create','store','edit','update']);
    Route::get('vpn', [\App\Http\Controllers\Admin\VpnClientController::class,'index'])->name('vpn.index');
    Route::get('vpn/create', [\App\Http\Controllers\Admin\VpnClientController::class,'create'])->name('vpn.create');
    Route::post('vpn', [\App\Http\Controllers\Admin\VpnClientController::class,'store'])->name('vpn.store');

    Route::get('vpn/{vpnClient}/edit', [\App\Http\Controllers\Admin\VpnClientController::class,'edit'])->name('vpn.edit');
    Route::put('vpn/{vpnClient}', [\App\Http\Controllers\Admin\VpnClientController::class,'update'])->name('vpn.update');

    Route::post('vpn/{vpnClient}/revoke', [\App\Http\Controllers\Admin\VpnClientController::class,'revoke'])->name('vpn.revoke');
    Route::post('vpn/{vpnClient}/renew', [\App\Http\Controllers\Admin\VpnClientController::class,'renew'])->name('vpn.renew');
    Route::get('vpn/{vpnClient}/download', [\App\Http\Controllers\Admin\VpnClientController::class,'download'])->name('vpn.download');

});
