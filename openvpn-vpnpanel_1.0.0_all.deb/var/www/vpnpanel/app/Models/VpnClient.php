<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VpnClient extends Model
{
    protected $fillable = [
      'base_name','cn','email',
      'validity_months',
      'cert_enddate','cert_not_after_at',
      'is_current','status','revoked_at'
    ];

    protected $casts = [
      'cert_not_after_at' => 'datetime',
      'revoked_at' => 'datetime',
      'is_current' => 'boolean',
    ];


    use HasFactory;
}
