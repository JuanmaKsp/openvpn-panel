<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\VpnClient;
use App\Services\VpnManager;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

class VpnClientController extends Controller
{
    public function index()
    {
        $items = VpnClient::where('is_current', true)->orderBy('id','desc')->get();
        return view('admin.vpn.index', compact('items'));
    }

    public function create()
    {
        return view('admin.vpn.create');
    }

    public function store(Request $r, VpnManager $vpn)
    {
        $data = $r->validate([
          'base_name' => 'required|string|max:64|regex:/^[A-Za-z0-9_-]+$/',
          'email' => 'required|email|max:190',
          'validity_months' => 'required|integer|min:1|max:120',
          'private_subnet' => 'nullable|string|max:32',
          'port' => 'nullable|integer|min:1|max:65535',
        ]);

        // CN único (para permitir renovaciones sin “pisar”)
        $cn = $data['base_name'].'-'.now()->format('YmdHis');

        $expireDays = $this->monthsToExpireDays((int)$data['validity_months']);

        $resp = $vpn->add(
          $cn,
          $data['email'],
          $data['private_subnet'] ?? null,
          isset($data['port']) ? (string)$data['port'] : null,
          $expireDays
        );

        VpnClient::create([
          'base_name' => $data['base_name'],
          'cn' => $cn,
          'email' => $data['email'],
          'validity_months' => (int)$data['validity_months'],
          'cert_enddate' => $resp['cert_enddate'] ?? null,
          'cert_not_after_at' => $this->parseNotAfter($resp['cert_enddate'] ?? null),
          'is_current' => true,
          'status' => 'active',
        ]);

        return redirect()->route('admin.vpn.index')->with('ok','Cliente VPN creado.');
    }

    public function revoke(VpnClient $vpnClient, VpnManager $vpn)
    {
        if (!$vpnClient->is_current) abort(404);

        $vpn->revoke($vpnClient->cn);

        $vpnClient->status = 'revoked';
        $vpnClient->revoked_at = now();
        $vpnClient->is_current = false;
        $vpnClient->save();

        return back()->with('ok','Cliente revocado.');
    }

    public function renew(VpnClient $vpnClient, VpnManager $vpn)
    {
        if (!$vpnClient->is_current) abort(404);

        // 1) Revocar el actual
        $vpn->revoke($vpnClient->cn);
        $vpnClient->status = 'revoked';
        $vpnClient->revoked_at = now();
        $vpnClient->is_current = false;
        $vpnClient->save();

        // 2) Crear nuevo CN
        $expireDays = $this->monthsToExpireDays((int)$vpnClient->validity_months);

        $newCn = $vpnClient->base_name.'-'.now()->format('YmdHis');
        $resp = $vpn->add($newCn, $vpnClient->email, null, null, $expireDays);

        VpnClient::create([
          'base_name' => $vpnClient->base_name,
          'cn' => $newCn,
          'email' => $vpnClient->email,
          'validity_months' => (int)$vpnClient->validity_months,
          'cert_enddate' => $resp['cert_enddate'] ?? null,
          'cert_not_after_at' => $this->parseNotAfter($resp['cert_enddate'] ?? null),
          'is_current' => true,
          'status' => 'active',
        ]);

        return redirect()->route('admin.vpn.index')->with('ok','VPN renovada (nuevo perfil generado).');
    }

    public function download(VpnClient $vpnClient, VpnManager $vpn)
    {
        if (!$vpnClient->is_current) abort(404);

        $res = $vpn->downloadProfile($vpnClient->cn);

        return response($res->body(), 200, [
            'Content-Type' => 'application/x-openvpn-profile',
            'Content-Disposition' => 'attachment; filename="'.$vpnClient->base_name.'.ovpn"',
        ]);
    }

    public function edit(VpnClient $vpnClient)
    {
        if (!$vpnClient->is_current) abort(404);
        return view('admin.vpn.edit', compact('vpnClient'));
    }

    public function update(Request $r, VpnClient $vpnClient)
    {
        if (!$vpnClient->is_current) abort(404);

        $data = $r->validate([
          'email' => 'required|email|max:190',
          'validity_months' => 'required|integer|min:1|max:120',
        ]);

        $vpnClient->email = $data['email'];
        $vpnClient->validity_months = (int)$data['validity_months'];
        $vpnClient->save();

        return redirect()->route('admin.vpn.index')->with('ok','Datos actualizados. (Se aplicará al renovar)');

    }
    
    private function monthsToExpireDays(int $months): int
    {
        $months = max(1, min(120, $months)); // 1..120 meses
        $now = now('UTC');
        $target = $now->copy()->addMonths($months);
        $days = (int) ceil($now->diffInSeconds($target) / 86400);
        return max(1, $days);
    }
    
    private function parseNotAfter(?string $s): ?Carbon
    {
        if (!$s) return null;
        $s = trim(str_replace('notAfter=', '', $s));
        $s = preg_replace('/\s+/', ' ', $s); // normaliza espacios
        try {
            // ejemplo: "Apr 26 06:49:06 2028 GMT"
            return Carbon::createFromFormat('M j H:i:s Y T', $s, 'UTC');
        } catch (\Throwable $e) {
            try { return Carbon::parse($s)->setTimezone('UTC'); } catch (\Throwable $e2) { return null; }
        }
    }
}
