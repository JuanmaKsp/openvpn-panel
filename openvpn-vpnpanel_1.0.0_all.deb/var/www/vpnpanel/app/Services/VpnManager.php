<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class VpnManager
{
    private string $url;
    private string $token;

    public function __construct()
    {
        $this->url = rtrim(env('VPNMGR_URL', 'http://127.0.0.1:9187'), '/');
        $this->token = env('VPNMGR_TOKEN', '');
    }

    private function client()
    {
        return Http::withToken($this->token)->timeout(30);
    }

    public function add(string $name, string $email, ?string $privateSubnet = null, ?string $port = null, ?int $certExpireDays = null): array
    {
      return $this->client()->post($this->url.'/add', [
          'name' => $name,
          'email' => $email,
          'private_subnet' => $privateSubnet,
          'port' => $port,
          'cert_expire_days' => $certExpireDays,
        ])->throw()->json();
    }

    public function revoke(string $name): array
    {
        return $this->client()->post($this->url.'/revoke', [
            'name' => $name,
        ])->throw()->json();
    }

    public function status(string $name): array
    {
        return $this->client()->get($this->url.'/status/'.rawurlencode($name))->throw()->json();
    }

    public function downloadProfile(string $name)
    {
        return $this->client()
            ->withOptions(['stream' => true])
            ->get($this->url.'/profile/'.rawurlencode($name))
            ->throw();
    }
}
