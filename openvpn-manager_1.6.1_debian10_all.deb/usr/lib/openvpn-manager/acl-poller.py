#!/usr/bin/env python3
"""
acl-poller — mantiene la cadena iptables OVPN_ACL sincronizada con los
clientes VPN actualmente conectados que tienen "Rangos de acceso"
configurados en el panel.

Corre fuera de OpenVPN por completo (no usa client-connect/client-disconnect,
no toca el chroot ni la degradacion a "nobody" del propio proceso OpenVPN):
sondea la interfaz de gestion cada POLL_INTERVAL segundos, exactamente igual
que ya hace app.py para mostrar quien esta conectado, y reconstruye la
cadena OVPN_ACL solo cuando el estado deseado cambia.

Fail-closed: un cliente restringido cuyos rangos resulten invalidos/vacios
tras validar se bloquea por completo (DROP), nunca se deja sin restriccion.
Fail-open a nivel de proceso: cualquier error de una vuelta del bucle
(interfaz de gestion caida, JSON corrupto, etc.) se registra y se reintenta
en el siguiente ciclo — nunca debe morir el servicio por un fallo puntual.
"""
import socket
import json
import os
import subprocess
import ipaddress
import time
import logging
import signal
import sys

MGMT_HOST      = '127.0.0.1'
MGMT_PORT      = 7505
META_FILE      = '/var/www/openvpn/clients_meta.json'
CHAIN_NAME     = 'OVPN_ACL'
IPTABLES_BIN   = '/usr/sbin/iptables-legacy'
POLL_INTERVAL  = 2  # segundos

# Cache de "quien esta conectado ahora" para que app.py (badge de conexion
# en "Clientes VPN") no tenga que abrir su propia conexion a la interfaz de
# gestion -- eso evitaria del todo el riesgo de contencion del puerto 7505
# (solo admite un cliente a la vez) y no añade NINGUN trafico nuevo hacia
# OpenVPN: el dato ya se consulta aqui, cada POLL_INTERVAL segundos, para
# el propio cortafuegos. El directorio lo crea systemd (RuntimeDirectory=
# en el .service), asi que existe con los permisos correctos antes de que
# este proceso arranque.
CONNECTED_CACHE_FILE = '/run/openvpn-manager/connected.json'

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)],  # systemd/journald lo captura
)
log = logging.getLogger('acl-poller')

_running = True


def _handle_sigterm(signum, frame):
    global _running
    _running = False


signal.signal(signal.SIGTERM, _handle_sigterm)
signal.signal(signal.SIGINT, _handle_sigterm)


def get_connected_clients():
    """Devuelve {common_name: virtual_ip} de los clientes conectados ahora
    mismo, consultando la interfaz de gestion (igual que app.py).

    Se abre y cierra una conexion nueva en cada sondeo (en vez de mantener
    una persistente) A PROPOSITO: la interfaz de gestion de OpenVPN solo
    admite UN cliente conectado a la vez. Una version anterior de este
    fichero mantenia la conexion abierta permanentemente para reducir el
    ruido "MANAGEMENT: ..." en el journal -- pero eso ocupaba el unico
    hueco disponible todo el tiempo, y bloqueaba durante 3s (timeout) cada
    consulta que el propio panel (app.py) hace al cargar "Clientes VPN" o
    al bloquear/desconectar un cliente -- regresion real encontrada en
    produccion. El ruido en el journal ya se mitiga de otras dos formas
    (el panel filtra y busca sobre el journal en vez de leer las ultimas N
    lineas en crudo, y el journal ahora es persistente en disco en vez de
    un tmpfs pequeño), asi que se prioriza no monopolizar la interfaz de
    gestion sobre reducir aun mas ese ruido."""
    result = {}
    try:
        s = socket.create_connection((MGMT_HOST, MGMT_PORT), timeout=3)
        s.recv(1024)
        s.sendall(b'status 2\n')
        data = b''
        while b'\nEND' not in data:
            chunk = s.recv(4096)
            if not chunk:
                break
            data += chunk
        s.sendall(b'quit\n')
        s.close()
        for line in data.decode(errors='ignore').splitlines():
            if line.startswith('CLIENT_LIST,'):
                parts = line.split(',')
                # CLIENT_LIST,Common Name,Real Address,Virtual Address,...
                if len(parts) > 3 and parts[1] and parts[3]:
                    result[parts[1]] = parts[3]
    except (ConnectionRefusedError, OSError, socket.timeout) as e:
        log.warning('no se pudo consultar la interfaz de gestion: %s', e)
    return result


def load_ranges():
    """Devuelve {name: [cidrs]} para clientes con ip_ranges no vacio."""
    try:
        with open(META_FILE) as f:
            meta = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        log.warning('no se pudo leer %s: %s', META_FILE, e)
        return {}
    ranges = {}
    for name, data in meta.items():
        cidrs = data.get('ip_ranges') or []
        if cidrs:
            ranges[name] = cidrs
    return ranges


def valid_cidr(cidr):
    try:
        net = ipaddress.ip_network(cidr, strict=False)
        if net.version != 4:
            return None
        return str(net)
    except ValueError:
        return None


def write_connected_cache(connected):
    """Escribe {name: virtual_ip} para que app.py lo lea sin tener que
    consultar la interfaz de gestion por su cuenta. Escritura atomica
    (fichero temporal + rename) para que una lectura a medio escribir
    nunca vea JSON incompleto."""
    try:
        tmp = CONNECTED_CACHE_FILE + '.tmp'
        with open(tmp, 'w') as f:
            json.dump(connected, f)
        os.chmod(tmp, 0o640)
        os.replace(tmp, CONNECTED_CACHE_FILE)
    except OSError as e:
        log.warning('no se pudo escribir la cache de conectados: %s', e)


def build_desired_state(connected):
    """{virtual_ip: [cidrs_validos]} solo para clientes conectados Y con
    rango configurado. Un cliente con rango pero SIN ningun CIDR valido
    tras validar aparece con lista vacia -> se traduce en DROP total
    (fail-closed), nunca en ausencia de reglas."""
    ranges = load_ranges()
    state = {}
    for name, cidrs in ranges.items():
        vip = connected.get(name)
        if not vip:
            continue  # no conectado ahora mismo, no necesita reglas
        valid = [c for c in (valid_cidr(c) for c in cidrs) if c]
        state[vip] = sorted(valid)
    return state


def run_iptables(args):
    try:
        r = subprocess.run([IPTABLES_BIN] + args, capture_output=True, text=True, timeout=5)
        if r.returncode != 0:
            log.warning('iptables-legacy %s fallo: %s', args, r.stderr.strip())
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError) as e:
        log.error('no se pudo ejecutar iptables-legacy %s: %s', args, e)
        return False


def apply_state(state):
    """Devuelve True solo si TODAS las operaciones de iptables-legacy
    tuvieron exito. Si algo falla (p.ej. permiso), el estado no debe darse
    por aplicado, para que el siguiente ciclo lo reintente en vez de
    quedarse "atascado" pensando que ya esta correcto."""
    ok = run_iptables(['-F', CHAIN_NAME])
    for vip, cidrs in state.items():
        src = f'{vip}/32'
        for cidr in cidrs:
            ok = run_iptables(['-A', CHAIN_NAME, '-s', src, '-d', cidr, '-j', 'RETURN']) and ok
        ok = run_iptables(['-A', CHAIN_NAME, '-s', src, '-j', 'DROP']) and ok
        if not cidrs:
            log.warning('cliente en %s sin ningun CIDR valido: bloqueado por completo', vip)
    return ok


def main():
    log.info('acl-poller arrancando, intervalo=%ss', POLL_INTERVAL)
    last_state = None
    while _running:
        try:
            connected = get_connected_clients()
            write_connected_cache(connected)
            state = build_desired_state(connected)
            if state != last_state:
                log.info('cambio de estado detectado, reconstruyendo %s: %s',
                          CHAIN_NAME, {k: len(v) for k, v in state.items()})
                if apply_state(state):
                    last_state = state
                else:
                    log.warning('la reconstruccion de %s fallo parcial o totalmente, se reintentara', CHAIN_NAME)
        except Exception:
            log.exception('error inesperado en el ciclo de sondeo, se reintenta')
        for _ in range(POLL_INTERVAL * 10):
            if not _running:
                break
            time.sleep(0.1)
    log.info('acl-poller detenido')


if __name__ == '__main__':
    main()
